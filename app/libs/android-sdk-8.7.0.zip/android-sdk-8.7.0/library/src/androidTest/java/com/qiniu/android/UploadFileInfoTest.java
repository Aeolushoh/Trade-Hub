package com.qiniu.android;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class UploadFileInfoTest extends BaseTest {

    @Test
    public void testCreateFromJsonError(){


//        UploadFileInfo fileInfo = UploadFileInfo.fileFromJson(null);
//
//        assertTrue(fileInfo == null);
//
//        fileInfo = new UploadFileInfo(0, 1 , 1);
//        assertTrue(fileInfo.progress() == 0);
//
//        assertTrue(fileInfo.nextUploadData() == null);
//
//        assertTrue(fileInfo.isAllUploaded() == true);
//
//        fileInfo.clearUploadState();
//
//
//        UploadFileInfo.UploadData data = UploadFileInfo.UploadData.dataFromJson(null);
//
//        assertTrue(data == null);

    }

}
