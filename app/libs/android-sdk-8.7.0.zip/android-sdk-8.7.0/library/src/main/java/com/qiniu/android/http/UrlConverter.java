package com.qiniu.android.http;

public interface UrlConverter {
    String convert(String url);
}
