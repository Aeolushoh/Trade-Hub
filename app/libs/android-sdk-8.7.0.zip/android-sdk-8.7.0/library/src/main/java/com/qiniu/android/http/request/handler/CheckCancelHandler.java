package com.qiniu.android.http.request.handler;

public interface CheckCancelHandler {
    boolean checkCancel();
}
