package com.qiniu.android.storage;

/**
 * Created by bailong on 16/9/7.
 */
public interface NetReadyHandler {
    void waitReady();
}
